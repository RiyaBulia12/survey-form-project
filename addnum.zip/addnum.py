# Write a simple python program that adds 2 numbers together and output the result on your terminal.

# Your python program should use variables to carry out the addition


def addnum(x, y):
    return x+y


addnum(2, 5)
