# Write a simple python program that outputs “Hello World” on your terminal

def hello():
    print("Hello World")


hello()
